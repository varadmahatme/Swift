import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            List{
                Text("Varad's App")
            }
        }
    }
            
}
